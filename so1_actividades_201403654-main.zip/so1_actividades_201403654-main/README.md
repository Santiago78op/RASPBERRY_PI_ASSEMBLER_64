# Repositorio actividades de sistemas operativos 1 .
Repositorio sobre distintas actividades que se desarrollaran en la clase de sistemas operativos 1.
