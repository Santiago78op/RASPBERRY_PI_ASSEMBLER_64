#!/bin/bash
echo "Hola usuario, el dia de hoy es $(date)"