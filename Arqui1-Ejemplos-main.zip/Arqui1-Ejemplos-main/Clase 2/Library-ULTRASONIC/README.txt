/************/
/* SIMULINO */
/************/



/***********************/
/* PT (Como Instalar)  */
/***********************/

- Copie o arquivo BLOGEMBARCADO.LIB para a pasta:

C:\Arquivos de Programas\Labcenter Electronics\Proteus 7 Professional\LIBRARY
ou
C:\Arquivos de Programas\Labcenter Electronics\Proteus 8 Professional\Data\LIBRARY



/***********************/
/* EN (How to Install) */
/***********************/

- Copy the file BLOGEMBARCADO.LIB for the folder:

C:\Program Files\Labcenter Electronics\Proteus 7 Professional\LIBRARY
or
C:\Program Files\Labcenter Electronics\Proteus 8 Professional\Data\LIBRARY




/**************************************/
/* EN (Windows 7 ou 8 with Proteus 8) */
/**************************************/

- Copy the file BLOGEMBARCADO.LIB for the folder:

C:\ProgramData\Labcenter Electronics\Proteus 8 Professional\Data\LIBRARY




/***********************/
/*                     */
/***********************/

PT (Veja mais instrucoes de uso no blog)
EN (See more instructions for use on blog)




http://blogembarcado.blogspot.com

